#!/usr/bin/env bash
sudo apt-get --yes update
sudo apt-get --yes upgrade
sudo apt-get --yes install r-base-core 
## this downloads the tool that allows R to find and downloads certain packages needed for analysis.
sudo apt-get --yes install r-cran-rmysql
sudo apt-get --yes install ipvsadm
sudo apt-get --yes install dkms
##this updates java for the picard tool
sudo apt-add-repository ppa:openjdk-r/ppa
sudo apt-get --yes update
sudo apt-get --yes upgrade
sudo apt-get --yes install openjdk-8-jdk
sudo update-alternatives --config java
##this installs curl and other attachments for adding R packages later
sudo apt-get --yes update
sudo apt-get --yes upgrade
sudo apt-get --yes install curl
sudo apt-get --yes install php5-curl
sudo apt-get --yes install aptitude
sudo apt-get --yes install libcurl4-openssl-dev
sudo apt-get --yes install libxml2-dev
sudo apt-get --yes install libssl-dev
sudo apt-get --yes install libgsl0ldbl
sudo apt-get --yes install gsl-bin libgsl2
sudo apt-get --yes install libtiff-dev
sudo apt-get --yes install build-essential python2.7-dev python-htseq
mkdir /home/ubuntu/AIDD
mkdir /home/ubuntu/AIDD/AIDD_tools
mkdir /home/ubuntu/AIDD/AIDD_tools/bin
##sratoolkit
wget http://ftp-trace.ncbi.nlm.nih.gov/sra/sdk/current/sratoolkit.current-ubuntu64.tar.gz -O sratoolkit.tar.gz
tar -vxzf /home/ubuntu/sratoolkit.tar.gz
rm /home/ubuntu/sratoolkit.tar.gz
mv /home/ubuntu/sratoolkit.2.9.2-ubuntu64/ /home/ubuntu/AIDD/AIDD_tools/
cp /home/ubuntu/AIDD/AIDD_tools/sratoolkit.2.9.2-ubuntu64/bin/* /home/ubuntu/AIDD/AIDD_tools/bin
##samtools
wget https://github.com/samtools/samtools/releases/download/1.3.1/samtools-1.3.1.tar.bz2 -O /home/ubuntu/samtools.tar.bz2
tar -xjvf samtools.tar.bz2
rm /home/ubuntu/samtools.tar.bz2
cd /home/ubuntu/samtools-1.3.1
make
sudo make prefix=/usr/local/bin install
cp /home/ubuntu/samtools-1.3.1/samtools /home/ubuntu/AIDD/AIDD_tools/bin
cd /home/ubuntu/
mv /home/ubuntu/samtools-1.3.1 /home/ubuntu/AIDD/AIDD_tools
##install HISAT2
wget ftp://ftp.ccb.jhu.edu/pub/infphilo/hisat2/downloads/hisat2-2.1.0-Linux_x86_64.zip
unzip /home/ubuntu/hisat2-2.1.0-Linux_x86_64.zip
rm /home/ubuntu/hisat2-2.1.0-Linux_x86_64.zip
cp /home/ubuntu/hisat2-2.1.0/* /home/ubuntu/AIDD/AIDD_tools/bin
mv /home/ubuntu/hisat2-2.1.0 /home/ubuntu/AIDD/AIDD_tools
## install stringtie
wget http://ccb.jhu.edu/software/stringtie/dl/stringtie-1.3.3b.tar.gz
tar -vxzf stringtie-1.3.3b.tar.gz
rm /home/ubuntu/stringtie-1.3.3b.tar.gz
cd /home/ubuntu/stringtie-1.3.3b
make release
cd /home/ubuntu/
cp /home/ubuntu/stringtie-1.3.3b/stringtie /home/ubuntu/AIDD/AIDD_tools/bin
mv /home/ubuntu/stringtie-1.3.3b /home/ubuntu/AIDD/AIDD_tools
wget http://ccb.jhu.edu/software/stringtie/dl/prepDE.py
mv /home/ubuntu/prepDE.py /home/ubuntu/AIDD/AIDD_tools/bin
##picard tool
wget https://github.com/broadinstitute/picard/archive/2.17.3.tar.gz
tar -vxzf 2.17.3.tar.gz
rm /home/ubuntu/2.17.3.tar.gz
wget https://github.com/broadinstitute/picard/releases/download/2.17.3/picard.jar
mv /home/ubuntu/picard.jar /home/ubuntu/AIDD/AIDD_tools/picard.jar
mv /home/ubuntu/picard-2.17.3 /home/ubuntu/AIDD/AIDD_tools
## this downloads GATK
cd /home/ubuntu/AIDD/AIDD_tools/
wget https://github.com/RNAdetective/AIDD/raw/master/GenomeAnalysisTK.jar
cd /home/ubuntu/
## download fastqc
wget https://www.bioinformatics.babraham.ac.uk/projects/fastqc/fastqc_v0.11.7.zip
unzip fastqc_v0.11.7.zip
mv /home/ubuntu/FastQC/ /home/ubuntu/AIDD/AIDD_tools/
cp /home/ubuntu/AIDD/AIDD_tools/FastQC/fastqc /home/ubuntu/AIDD/AIDD_tools/bin/
rm /home/ubuntu/fastqc_v0.11.7.zip
## install snpEff
wget http://sourceforge.net/projects/snpeff/files/snpEff_latest_core.zip
unzip snpEff_latest_core.zip
rm /home/ubuntu/snpEff_latest_core.zip
cp /home/ubuntu/snpEff/snpEff.jar /home/ubuntu/AIDD/AIDD_tools/snpEff.jar
cp /home/ubuntu/snpEff/snpEff.config /home/ubuntu/AIDD/AIDD_tools/snpEff.config
mv /home/ubuntu/snpEff /home/ubuntu/AIDD/AIDD_tools
mv /home/ubuntu/clinEff /home/ubuntu/AIDD/AIDD_tools
##this will get pipeline scripts
wget https://github.com/RNAdetective/AIDD/raw/master/AIDD_AWSscripts.tar.xz
tar -vxzf AIDD_AWSscripts.tar.xz
mkdir /home/ubuntu/AIDD/AIDD/
mv /home/ubuntu/AIDD_AWSscripts/* /home/ubuntu/AIDD/AIDD/
## remove the files not needed
rm /home/ubuntu/AIDD_AWSscripts.tar.gz
## this will download the GRCh37 reference set for the pipeline
mkdir /home/ubuntu/AIDD/references/
bash /home/ubuntu/AIDD/AIDD/prep/downloads.sh
