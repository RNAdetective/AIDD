create_dir() {
if [ ! -d "$new_dir" ];
then
  mkdir "$new_dir"
fi
} # this creates directories $new_dir
temp_file() {
if [ -s "$dir_path"/temp.csv ];
then
  rm "$file_in"
  mv "$dir_path"/temp.csv "$file_in"
fi
}
name_files() {
temp=$(echo "$dir_count" | sed 's/\//,/g')
dirnum=$(echo "$temp" | grep -o "," | wc -l)
filenum=$(expr "$dirnum" + 2)
extnum=$(expr "$dirnum" + 3)
dir_name=$(echo "$files" | sed 's/\//./g' | cut -f "$filenum" -d '.')
res="${dir_name//[^_]}"
if [ "$res" == "" ];
then
  file_name=$(echo "$dir_name" | cut -f 1 -d '.') 
  #sample=$(echo "$file_name" | cut -f 1 -d ':')
else
  file_name=$(echo "$dir_name" | cut -f 1 -d '.' | cut -f 1-"${#res}" -d '_' )
  #sample=$(echo "$file_name" | cut -f 1 -d ':')
fi
file_ext=$(echo "$files" | sed 's/\//./g' | cut -f "$extnum" -d '.') 
}
mergeR() {
Rscript "$ExToolset"/multimerge.R "$cur_wkd" "$names" "$file_out" "$Rtool" "$Rtype" "$summaryfile" "$mergefile" "$phenofile" "$level_name" "$GOI_file" "$temp_file1" "$temp_file2" "$temp_file3" "$rename" #creates level of interest files
} # Runs multimerge R
dir_path=/home/user/Downloads
raw_dir="$dir_path"/impact_csv
dir_count="$raw_dir"
ExToolset=/home/user/AIDD/AIDD/ExToolset/scripts
for files in "$dir_count"/* ;
do
  echo "$files"
  name_files
  echo "$file_name"
  file_name2=$(echo "$file_name" | sed 's/snpEff//g' | sed 's/ADARediting//g')
  out_dir="$dir_path"/mergeimpactcsv
  new_dir="$out_dir"
  create_dir
  cat "$files" | awk -F ',' 'NR > 86 {print $1,$3}' | awk -F',' 'NR < 33 {print $1,$2}' | sed 's/ /,/' | sed '1i impact,'$file_name2'percent'  >> "$out_dir"/"$file_name2".csv
done
cd "$out_dir"
cur_wkd="$out_dir"
Rtool=$(echo "I_VEX")
Rtype=$(echo "multi")
GOI_file="$dir_path"/impactpercent.csv
summaryfile=none
tempfile3=transpose
names=$(echo "coord")
file_out="$dir_path"/impactpercent.csv
mergeR
