#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(ggplot2)) #loads packages
suppressPackageStartupMessages(library(plyr))
suppressPackageStartupMessages(library(ggpubr))
suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(Hmisc))
file_in <- "/home/user/Downloads/MDDfinaltables/allscoresfinal.csv"
file_out <- "/home/user/Downloads/MDDfinaltables/phenotypescore.tiff"
data <- read.csv(file_in) # reads input file into R
tiff(file_out, units="in", width=15, height=15, res=300) # this sets image size and resolution
data_plot <- data %>% # dply function to load data
group_by(COD, gender, tissue) %>% # this function groups data by three columns
summarize(average = mean (MLE), sd=sd(MLE)) # this calculates average and standard deviation
my_plot <- ggplot(data_plot, aes(x=COD, y=MLE, fill=COD)) + geom_bar(colour="black", stat="identity", position=position_dodge()) # makes basic bar plot
my_plot2 <- my_plot + facet_grid(vars(gender), vars(tissue)) # adds facets which will divid graph into segemtns based on a variable
my_plot3 <- my_plot2 + scale_fill_manual(values=c('red','blue')) + geom_errorbar(aes(ymin=average, ymax=average+sd), width=.2, position=position_dodge(.9)) # this adds color choice to bars and error bars with standard deviation
my_plot4 <- my_plot3 + theme_bw() + theme(panel.grid.major = element_blank() + panel.grid.minor = element_blank()) #this moves grid lines
my_plot5 <- my_plot4 + theme(legend.position="bottom") + guides(colour = guide_legend(override.aes = list(size=12))) # this edits the legend placement and size
my_plot6 <- my_plot5 + theme(text = element_text(size=20)) + theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) # this removes x axis since you have the same labels as colors in your legend
my_plot6 # prints the plot so you can save it.
dev.off() # this turns off the picture saving and will save graph to file specified.

file_in <- "/home/user/Downloads/MDDfinaltables/allscoresfinal.csv"
file_out <- "/home/user/Downloads/MDDfinaltables/MDDscore3.tiff"
tiff(file_out, units="in", width=15, height=10, res=300) # this sets image size and resolution
data <- read.csv("/home/user/Downloads/MDDfinaltables/allscoresfinal.csv")
# New facet label names for dose variable
tissue <- c("aINS", "Cg25", "dlPFC9B","dlPFCB8_9","Nac","OFC","Subiculum(Sub)")
names(tissue) <- c("aINS", "Cg25", "PFCB9","dlPFC","NAcc","OFC","Subiculum")
my_plot <- ggplot(data, aes(x=COD, y=MLE, fill=COD)) + geom_violin(trim=TRUE) # makes basic bar plot
my_plot2 <- my_plot + facet_grid(gender~tissue,labeller = labeller(tissue=tissue)
  )) # adds facets which will divid graph into segemtns based on a variable
my_plot3 <- my_plot2 + scale_fill_manual(values=c('red','blue')) + geom_jitter(shape=16, position=position_jitter(0.1), size=2)
my_plot4 <- my_plot3 + theme_bw() + geom_boxplot(width=0.2)
my_plot5 <- my_plot4 + theme(legend.position="bottom") + guides(colour = guide_legend(override.aes = list(size=12))) # this edits the legend placement and size
my_plot6 <- my_plot5 + theme(text = element_text(size=16)) + theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) # this removes x axis since you have the same labels as colors in your legend
my_plot6 # prints the plot so you can save it.
dev.off()


file_in <- "/home/user/Downloads/MDDfinaltables/variantFilteringVisualFinal2.csv"
file_out <- "/home/user/Downloads/MDDfinaltables/GlobalADAReditingCOD3.tiff"
tiff(file_out, units="in", width=15, height=10, res=300) # this sets image size and resolution
data <- read.csv(file_in)
data2 <- data %>%
filter(sub == "ADAR") %>%
filter(type == "nonsnps") %>%
filter(name == "filtered_snps_finalAll") %>%
filter(COD != "Accident")
# New facet label names for dose variable
tissue <- c("aINS", "Cg25", "dlPFC9B","dlPFCB8_9","Nac","OFC","Subiculum (Sub)")
names(tissue) <- c("aINS", "Cg25", "PFCB9","dlPFC","NAcc","OFC","Subiculum")
my_plot <- ggplot(data2, aes(x=COD, y=variants, fill=COD)) + geom_violin(trim=TRUE) # makes basic bar plot
my_plot2 <- my_plot + facet_grid(gender~tissue,labeller=(tissue=tissue)) # adds facets which will divid graph into segemtns based on a variable
my_plot3 <- my_plot2 + scale_fill_manual(values=c('blue','red')) + geom_jitter(shape=16, position=position_jitter(0.1), size=2)
my_plot4 <- my_plot3 + theme_bw() + geom_boxplot(width=0.2)
my_plot5 <- my_plot4 + theme(legend.position="bottom") + guides(colour = guide_legend(override.aes = list(size=12))) # this edits the legend placement and size
my_plot6 <- my_plot5 + theme(text = element_text(size=16)) + theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) # this removes x axis since you have the same labels as colors in your legend
my_plot6 # prints the                      plot so you can save it.
dev.off()





file_in <- "/home/user/Documents/pathwayfold.csv"
file_out <- "/home/user/Documents/pathwayfold.tiff"
data <- read.csv(file_in) # reads input file into R
tiff(file_out, units="in", width=25, height=10, res=300) # this sets image size and resolution
my_plot <- ggplot(data, aes(x=biological_process, y=fold, fill=biological_process)) + geom_bar(colour="black", stat="identity", position=position_dodge())
my_plot2 <- my_plot + theme(legend.position="none")  + theme(text = element_text(size=16)) + theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank())  + coord_flip()   # prints the plot so you can save it.
my_plot2
dev.off() # this turns off the picture saving and will save graph to file specified.


+ stat_summary(fun.data=mean_sdl, geom="pointrange", color="black")
 + geom_boxplot(width=0.1)
+ geom_dotplot(binaxis='y', stackdir='center', position=position_dodge(1))


##Pie Chart
data <- read.csv("/home/user /Documents/impactpercenttrans.csv")
data2 <- data %>%
gather(impact,percent,-COD,-sample,-Sex,-Region,-MDD)
head(data2)
data2$percent <- factor(data2$percent, levels = data2$percent)



data <- read.csv("/home/user/Downloads/CombinedCountsFinal.csv")
data3 <- data2 %>%
group_by(MDD,Sex,Region,impact) %>%
summarize(average = mean(percent))
data <- read.csv("/home/user/Documents/pathwaypie.csv")
data$pathway <- factor(data$pathway, levels = data$pathway)
file_out <- "/home/user/Downloads/pathwaypie.tiff"
tiff(file_out, units="in", width=10,height=10,res=300)
plot <- ggplot(data, aes(x="",y=percent,fill=pathway)) + geom_bar(stat="identity",width=1,color="black") + scale_fill_brewer(palette = "Paired") 
plot2 <- plot + coord_polar("y", start=0) + theme_void() + geom_text(aes(label = paste0(percent2, "%"),, x = 1.6),position = position_stack(vjust = 0.5)) + labs(fill = "GO Pathway")
plot3 <- plot2 + theme(legend.position="bottom")
plot3
dev.off()



data <- read.csv("/home/user/Downloads/CombinedCountsFinal.csv")
data3 <- data2 %>%
group_by(COD,Sex,Region,impact) %>%
summarize(average = mean(percent))
file_out <- "/home/user/Downloads/ImpactPieChartsCOD.tiff"
tiff(file_out, units="in", width=17,height=10,res=300)
plot <- ggplot(data3, aes(x="",y=average,fill=impact)) + geom_bar(stat="identity",width=1,color="white") + facet_grid(vars(Sex,COD),vars(Region)) + scale_fill_brewer(palette = "Paired")
plot2 <- plot + coord_polar("y", start=0) + theme_void()
plot2
dev.off()


















data <- read.csv("/home/user/Downloads/CombinedCountsFinal.csv")
data2 <- data %>%
filter(type == "ADAR") %>%
filter(COD != "Accident") %>%
group_by(MDD,location) %>%
summarize(average = mean(percent))
file_out <- "/home/user/Downloads/LocationPieChartsMDD2.tiff"
tiff(file_out, units="in", width=17,height=10,res=300)
plot <- ggplot(data2, aes(x="",y=average,fill=location)) + geom_bar(stat="identity",width=1,color="white") + facet_grid(vars(MDD)) + scale_fill_brewer(palette = "Paired")
plot2 <- plot + coord_polar("y", start=0) + theme_void()
plot2
dev.off()

data <- read.csv("/home/user/Downloads/CombinedCountsFinal.csv")
data2 <- data %>%
filter(type == "ADAR") %>%
filter(COD != "Accident") %>%
group_by(COD,gender,location) %>%
summarize(average = mean(percent))
file_out <- "/home/user/Downloads/LocationPieChartsCOD3.tiff"
tiff(file_out, units="in", width=17,height=10,res=300)
plot <- ggplot(data2, aes(x="",y=average,fill=location)) + geom_bar(stat="identity",width=1,color="white") + facet_grid(vars(COD),vars(gender)) + scale_fill_brewer(palette = "Paired")
plot2 <- plot + coord_polar("y", start=0) + theme_void()
plot2
dev.off()
