setwd("/media/sf_AIDD/Results/variant_calling/sub_level/merge")
 
file_list <- list.files()
 
for (file in file_list){
       
  # if the merged dataset doesn't exist, create it
  if (!exists("dataset")){
    dataset <- read.csv(file)
  }
   
  # if the merged dataset does exist, append to it
  if (exists("dataset")){
    temp_dataset <-read.csv(file)
    dataset<-merge(dataset, temp_dataset, by="sub_names")
    rm(temp_dataset)
  }
 dataset$A1BM_1.x <- NULL
 colnames(dataset)[2] <- "A1BM_1"
 write.csv(dataset, "/media/sf_AIDD/Results/variant_calling/sub_level/sub_levelfinal.csv", row.names=FALSE)
}

