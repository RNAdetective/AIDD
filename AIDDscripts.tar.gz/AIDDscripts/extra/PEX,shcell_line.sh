#!/usr/bin/env bash
##This will run pathway by cell line seperately by first condition
sed -i 's/.csv/cell_line.csv/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/readcell_line/read/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/writecell_line/write/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/file_namecell_line/file_name/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/resultsallcell_line.csv/resultsall.csv/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/set_design/~ condition/g' /media/sf_AIDD/ExToolset/Gpathway.R 
sed -i 's/.tiff/cell_line.tiff/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/condition_1/'$conditionname1'/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/condition_2/'$conditionname2'/g' /media/sf_AIDD/ExToolset/Gpathway.R
for i in gene transcript ; do
for l in $cell_linename1 $cell_linename2 $cell_linename3 ; do
sed -i 's/level/'$i'/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/cell_line/'$l'/g' /media/sf_AIDD/ExToolset/Gpathway.R
INPUT=/media/sf_AIDD/gene_list/pathway/pathway_list.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x file_name
do
    sed -i 's/file_name/'$file_name'/g' /media/sf_AIDD/ExToolset/Gpathway.R
    Rscript /media/sf_AIDD/ExToolset/Gpathway.R
    sed -i 's/'$file_name'/file_name/g' /media/sf_AIDD/ExToolset/Gpathway.R
done < $INPUT
IFS=$OLDIFS
sed -i 's/'$i'/level/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/'$l'/cell_line/g' /media/sf_AIDD/ExToolset/Gpathway.R
done
done
sed -i 's/cell_line//g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/'$condition1'/condition_1/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/'$condition2'/condition_2/g' /media/sf_AIDD/ExToolset/Gpathway.R
sed -i 's/~ condition/set_design/g' /media/sf_AIDD/ExToolset/Gpathway.R
##this will do bargraphs for IFN gene pathway list
for i in gene transcript ; do
for m in IFN ; do
sed -i 's/level/'$i'/g' /media/sf_AIDD/ExToolset/bargraphs.R
sed -i 's/set_barcolors/palette="Greens"/g' /media/sf_AIDD/ExToolset/bargraphs.R
sed -i 's/List_names/'$m'/g' /media/sf_AIDD/ExToolset/bargraphs.R
INPUT=/media/sf_AIDD/"$i"_list/DESeq2/"$i"ofinterest.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x gene_name
do
    sed -i "s/file_name/"$gene_name"/g" /media/sf_AIDD/ExToolset/bargraphs.R
    Rscript /media/sf_AIDD/ExToolset/bargraphs.R
    sed -i "s/"$gene_name"/file_name/g" /media/sf_AIDD/ExToolset/bargraphs.R
done < $INPUT
IFS=$OLDIFS
sed -i 's/'$i'/level/g' /media/sf_AIDD/ExToolset/bargraphs.R
sed -i 's/palette="Greens"/set_barcolors/g' /media/sf_AIDD/ExToolset/bargraphs.R
sed -i 's/'$m'/List_names/g' /media/sf_AIDD/ExToolset/bargraphs.R
done
done
