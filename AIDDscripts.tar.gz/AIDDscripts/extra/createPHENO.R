##this gets count files for individual experiments within bigger experiment this 
countData <- read.csv("/media/sf_AIDD/Results/DESeq2G/counts/gene_count_matrixedited.csv")
countDataF6 <- countData[ ,-c(8:19)]
write.csv(colDataF6, /media/sf_AIDD/Results/DESeq2G/counts/gene_count_matrixedited1.csv, row.names=FALSE)
countDataM6 <- countData[ ,-c(2:7,14:19)]
write.csv(colDataM6, /media/sf_AIDD/Results/DESeq2G/counts/gene_count_matrixedited2.csv, row.names=FALSE)
countDataL6 <- countData[ ,-c(2:13)]
write.csv(colDataL6, /media/sf_AIDD/Results/DESeq2G/counts/gene_count_matrixedited3.csv, row.names=FALSE)
colData <- read.csv("/media/sf_AIDD/PHENO_DATA.csv", row.names=1)
colDataF6 <- colData[-c(7:18), ]
write.csv(colDataF6, /media/sf_AIDD/PHENO_DATA1.csv, row.names=FALSE)
colDataM6 <- colData[-c(1:6, 13:18), ]
write.csv(colDataM6, /media/sf_AIDD/PHENO_DATA2.csv, row.names=FALSE)
colDataL6 <- colData[-c(1:12), ]
write.csv(colDataL6, /media/sf_AIDD/PHENO_DATA3.csv, row.names=FALSE)
