create_dir() {
if [ ! -d "$new_dir" ];
then
  mkdir "$new_dir"
fi
} # this creates directories $new_dir
temp_file() {
if [ -s "$dir_path"/temp.csv ];
then
  rm "$file_in"
  mv "$dir_path"/temp.csv "$file_in"
fi
}
name_files() {
temp=$(echo "$dir_count" | sed 's/\//,/g')
dirnum=$(echo "$temp" | grep -o "," | wc -l)
filenum=$(expr "$dirnum" + 2)
extnum=$(expr "$dirnum" + 3)
dir_name=$(echo "$files" | sed 's/\//./g' | cut -f "$filenum" -d '.')
res="${dir_name//[^_]}"
if [ "$res" == "" ];
then
  file_name=$(echo "$dir_name" | cut -f 1 -d '.') 
  #sample=$(echo "$file_name" | cut -f 1 -d ':')
else
  file_name=$(echo "$dir_name" | cut -f 1 -d '.' | cut -f 1-"${#res}" -d '_' )
  #sample=$(echo "$file_name" | cut -f 1 -d ':')
fi
file_ext=$(echo "$files" | sed 's/\//./g' | cut -f "$extnum" -d '.') 
}
cut_col() {
if [ ! -s "$out_dir"/"$file_name".csv ];
then
  cat "$raw_dir"/"$file_name".genes.txt | tr "\\t" "," | sed '1d' | sed '1d' | cut -d',' -f "$level_num",4,"$col_num" | sed 's/ADARediting//g' | sed 's/snpEff//g' | awk -F',' '$2 == "protein_coding" { print $1,$3 }' | sed '1i '$level'id,'$impact''$file_name'' | awk -F',' '!x[$1]++' | sed 's/ /,/g' >> "$out_dir"/"$file_name".csv
fi
}
mergeR() {
Rscript "$ExToolset"/multimerge.R "$cur_wkd" "$names" "$file_out" "$Rtool" "$Rtype" "$summaryfile" "$mergefile" "$phenofile" "$level_name" "$GOI_file" "$temp_file1" "$temp_file2" "$temp_file3" "$rename" #creates level of interest files
} # Runs multimerge R
dir_path=/home/user/Downloads
raw_dir="$dir_path"/impact_counts
dir_count="$raw_dir"
ExToolset=/home/user/AIDD/AIDD/ExToolset/scripts
for files in "$dir_count"/* ;
do
  echo "$files"
  name_files
  echo "$file_name"
  for impact in high moderate low ;
  do
    for level in gene transcript ;
    do
      if [ "$impact" == "high" ];
      then
        if [ "$level" == "gene" ];
        then
          level_num=2
          col_num=5
          out_dir="$dir_path"/"$impact"impact_"$level"counts_merge
          new_dir="$out_dir"
          create_dir
          cut_col
        else
          level_num=3
          col_num=5
          out_dir="$dir_path"/"$impact"impact_"$level"counts_merge
          new_dir="$out_dir"
          create_dir
          cut_col
        fi
      fi
      if [ "$impact" == "low" ];
      then
        if [ "$level" == "gene" ];
        then
          level_num=2
          col_num=6
          out_dir="$dir_path"/"$impact"impact_"$level"counts_merge
          new_dir="$out_dir"
          create_dir
          cut_col
        else
          level_num=3
          col_num=6
          out_dir="$dir_path"/"$impact"impact_"$level"counts_merge
          new_dir="$out_dir"
          create_dir
          cut_col
        fi
      fi
      if [ "$impact" == "moderate" ];
      then
        if [ "$level" == "gene" ];
        then
          level_num=2
          col_num=7
          out_dir="$dir_path"/"$impact"impact_"$level"counts_merge
          new_dir="$out_dir"
          create_dir
          cut_col
        else
          level_num=3
          col_num=7
          out_dir="$dir_path"/"$impact"impact_"$level"counts_merge
          new_dir="$out_dir"
          create_dir
          cut_col
        fi 
      fi
    done
  done
done
for impact in high low moderate ;
do
  for level in gene transcript ;
  do
    cd "$dir_path"/"$impact"impact_"$level"counts_merge
    cur_wkd="$dir_path"/"$impact"impact_"$level"counts_merge
    Rtool=$(echo "I_VEX")
    Rtype=$(echo "multi")
    GOI_file="$dir_path"/"$impact""$level"_count_matrixeditedDESeq2.csv
    summaryfile=none
    tempfile3=transpose
    names=$(echo "coord")
    file_out="$dir_path"/"$impact""$level"gene_count_matrixeditedDESeq2.csv
    if [ "$level" == "gene" ];
    then
      level_name=$(echo "geneid")
    else
      level_name=$(echo "transcriptid")
    fi
    if [ ! -s "$file_out" ];
    then
      mergeR
    else
      echo "Found "$file_out""
    fi
    file_in="$file_out"
    cat "$file_in" | sed 's/NA/0/g' >> "$dir_path"/temp.csv
    temp_file
  done
done
