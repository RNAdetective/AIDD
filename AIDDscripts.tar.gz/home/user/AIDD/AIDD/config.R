batch <- batch01
miRNA <- 1
scRNA <- 1
dir_path <- /home/user/batch01

con_name1 -> condition
