library("tibble")
library("dplyr")
library("plotly")
library("ggplot2")
table1 <- read.csv("/media/sf_AIDD/Results/DESeq2/level/differential_expression/List_names/List_namescell_line.csv", row.names=1)
table1[, c(1:7)] <- NULL
table2 <- t(table1)
pheno <- read.csv("/media/sf_AIDD/PHENO_DATAcell_line.csv", row.names=1)
pheno[, c(1,3)] <- NULL
table3 <- merge(pheno, table2, by="row.names")
head(table3)
table4 <- table3 %>% group_by(set_group) %>% summarise (file_nameavg = mean(file_name), file_namesd = sd(file_name))
write.csv(table4, "/media/sf_AIDD/Results/DESeq2/level/differential_expression/List_names/file_namemeansdcell_line.csv", row.names=FALSE)
jpeg("/media/sf_AIDD/Results/DESeq2/level/differential_expression/List_names/file_namemeancell_line.jpeg")
p <- ggplot(table4, aes(set_x, y=file_nameavg, set_fill)) + 
   geom_bar(stat="identity", color="black", position=position_dodge()) +
  geom_errorbar(aes(ymin=file_nameavg-file_namesd, ymax=file_nameavg+file_namesd), width=.4,
                 position=position_dodge(.9))
  
p + scale_fill_brewer(set_barcolors) + theme_minimal()
p
dev.off()
