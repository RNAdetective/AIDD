#!/usr/bin/env bash
cell_linename1=$(awk -F, 'NR==2{print $2}' /media/sf_AIDD/cell_line.csv)
cell_linename2=$(awk -F, 'NR==3{print $2}' /media/sf_AIDD/cell_line.csv)
cell_linename3=$(awk -F, 'NR==4{print $2}' /media/sf_AIDD/cell_line.csv)
for i in gene transcript ; do
for j in upreg downreg ; do
for k in vennall top100 ; do
for l in $cell_linename1 $cell_linename2 $cell_linename3 ; do
mkdir /media/sf_AIDD/Results/DESeq2/"$i"/differential_expression/"$l"/
mv /media/sf_AIDD/Results/DESeq2/"$i"/differential_expression/*"$l".csv /media/sf_AIDD/Results/DESeq2/"$i"/differential_expression/"$l"/
done
done
done
done
