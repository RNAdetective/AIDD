#https://crashcourse.housegordon.org/split-fasta-files.html
mkdir /media/sf_AIDD/directory
cd /media/sf_AIDD/directory
csplit -s -z /media/sf_AIDD/directory.csv '/>/' '{*}'
for i in xx* ; do \
  n=$(sed 's/$// ; s/ .*// ; 1q' "$i") ; \
  mv "$i" "$n.csv" ; \
 done
