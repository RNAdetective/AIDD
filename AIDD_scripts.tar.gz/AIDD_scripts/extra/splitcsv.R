setwd("/media/sf_AIDD/") 
mydata = read.csv("PHENO_DATAwhole.csv")
chunk1 <- sample(mydata[1:25,1:4]) 
write.csv(chunk1,file="PHENO_DATAbatch1.csv",quote=F,row.names=F)
chunk2 <- sample(mydata[25:49,1:4])
write.csv(chunk2,file="PHENO_DATAbatch2.csv",quote=F,row.names=F)
chunk3 <- sample(mydata[50:74,1:4])
write.csv(chunk3,file="PHENO_DATAbatch3.csv",quote=F,row.names=F)
chunk4 <- sample(mydata[75:99,1:4])
write.csv(chunk4,file="PHENO_DATAbatch4.csv",quote=F,row.names=F)
chunk5 <- sample(mydata[100:124,1:4])
write.csv(chunk5,file="PHENO_DATAbatch5.csv",quote=F,row.names=F)
chunk6 <- sample(mydata[125:149,1:4])
write.csv(chunk6,file="PHENO_DATAbatch6.csv",quote=F,row.names=F)
chunk7 <- sample(mydata[150:174,1:4])
write.csv(chunk7,file="PHENO_DATAbatch7.csv",quote=F,row.names=F)
chunk8 <- sample(mydata[175:199,1:4])
write.csv(chunk8,file="PHENO_DATAbatch8.csv",quote=F,row.names=F)
chunk9 <- sample(mydata[200:224,1:4])
write.csv(chunk9,file="PHENO_DATAbatch9.csv",quote=F,row.names=F)
chunk10 <- sample(mydata[225:249,1:4])
write.csv(chunk10,file="PHENO_DATAbatch10.csv",quote=F,row.names=F)
chunk11 <- sample(mydata[250:274,1:4])
write.csv(chunk11,file="PHENO_DATAbatch11.csv",quote=F,row.names=F)
chunk12 <- sample(mydata[275:299,1:4])
write.csv(chunk12,file="PHENO_DATAbatch12.csv",quote=F,row.names=F)
chunk13 <- sample(mydata[300:324,1:4])
write.csv(chunk14,file="PHENO_DATAbatch13.csv",quote=F,row.names=F)
chunk14 <- sample(mydata[325:349,1:4])
write.csv(chunk14,file="PHENO_DATAbatch14.csv",quote=F,row.names=F)
chunk15 <- sample(mydata[350:374,1:4])
write.csv(chunk15,file="PHENO_DATAbatch15.csv",quote=F,row.names=F)
chunk16 <- sample(mydata[375:399,1:4])
write.csv(chunk16,file="PHENO_DATAbatch16.csv",quote=F,row.names=F)
chunk17 <- sample(mydata[400:424,1:4])
write.csv(chunk17,file="PHENO_DATAbatch17.csv",quote=F,row.names=F)
chunk18 <- sample(mydata[425:449,1:4])
write.csv(chunk18,file="PHENO_DATAbatch18.csv",quote=F,row.names=F)
chunk19 <- sample(mydata[450:474,1:4])
write.csv(chunk19,file="PHENO_DATAbatch19.csv",quote=F,row.names=F)
chunk20 <- sample(mydata[475:499,1:4])
write.csv(chunk20,file="PHENO_DATAbatch20.csv",quote=F,row.names=F)
chunk21 <- sample(mydata[500:524,1:4])
write.csv(chunk21,file="PHENO_DATAbatch21.csv",quote=F,row.names=F)
chunk22 <- sample(mydata[525:549,1:4])
write.csv(chunk22,file="PHENO_DATAbatch22.csv",quote=F,row.names=F)
chunk23 <- sample(mydata[550:574,1:4])
write.csv(chunk23,file="PHENO_DATAbatch23.csv",quote=F,row.names=F)
chunk24 <- sample(mydata[575:599,1:4])
write.csv(chunk24,file="PHENO_DATAbatch24.csv",quote=F,row.names=F)
chunk25 <- sample(mydata[600:624,1:4])
write.csv(chunk25,file="PHENO_DATAbatch25.csv",quote=F,row.names=F)
chunk26 <- sample(mydata[625:649,1:4])
write.csv(chunk26,file="PHENO_DATAbatch26.csv",quote=F,row.names=F)
chunk27 <- sample(mydata[650:674,1:4])
write.csv(chunk27,file="PHENO_DATAbatch27.csv",quote=F,row.names=F)
chunk28 <- sample(mydata[675:699,1:4])
write.csv(chunk28,file="PHENO_DATAbatch28.csv",quote=F,row.names=F)
chunk29 <- sample(mydata[700:724,1:4])
write.csv(chunk29,file="PHENO_DATAbatch29.csv",quote=F,row.names=F)
chunk30 <- sample(mydata[725:735,1:4])
write.csv(chunk30,file="PHENO_DATAbatch30.csv",quote=F,row.names=F)






# If you want 5 different chunks with same number of lines, lets say 30.
Chunks = split(mydata,sample(rep(1:5,30)))  ## 5 Chunks of 30 lines each

# If you want 20 samples, put any range of 20 values within the range of number of rows
chunk1 <- sample(mydata[1:20,])  ## this would contain first 20 rows

# Or you can print any number of rows within the range
chunk2 <- sample(mydata[100:70,] ## this would contain last 30 rows in reverse order if your data had 100 rows.

# If you want to write these chunks out in a csv file:
write.csv(chunk1,file="chunk1.csv",quote=F,row.names=F)
write.csv(chunk2,file="chunk2.csv",quote=F,row.names=F)
