setwd("/media/sf_AIDD/Results/variant_calling/haplotype/level/snpEff_impact/cell_type")
 
file_list <- list.files()
 
for (file in file_list){
       
  # if the merged dataset doesn't exist, create it
  if (!exists("dataset")){
    dataset <- read.table(file, header=TRUE, sep=",")
  }
   
  # if the merged dataset does exist, append to it
  if (exists("dataset")){
    temp_dataset <-read.table(file, header=TRUE, sep=",")
    dataset<-merge(dataset, temp_dataset, by="level_id")
    rm(temp_dataset)
    dataset[order(dataset$cell_type1)]
    dataset[rowSums(dataset[, -1] > 0) != 0, ]
    write.table(dataset, cell_typeFinal.table, row.names=FALSE)
  }
 
}

