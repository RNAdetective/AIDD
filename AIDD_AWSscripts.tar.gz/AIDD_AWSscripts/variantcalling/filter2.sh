#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    ##second round of filtering same steps as first roung
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T SelectVariants -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_variants_recal.vcf -selectType SNP -o /home/ubuntu/batchnumber/working_directory/"$run"raw_snps_recal.vcf
    mv /home/ubuntu/batchnumber/working_directory/"$run"raw_snps_recal.vcf /home/ubuntu/batchnumber/raw_data/vcf_files/
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp  -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantsToTable -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_snps_recal.vcf -F CHROM -F POS -F ID -F QUAL -F AC -F BaseCounts -o /home/ubuntu/batchnumber/raw_data/vcf_files/"$run"raw_snps_recal.table
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T SelectVariants -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_variants_recal.vcf -selectType INDEL -o /home/ubuntu/batchnumber/working_directory/"$run"raw_indels_recal.vcf
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantFiltration -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_snps_recal.vcf --filterExpression 'QD < 2.0 || FS > 60.0 || MQ < 40.0 || SOR > 4.0' --filterName "basic_snp_filter" -o /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps_final.vcf
    mv /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps_final.vcf /home/ubuntu/batchnumber/raw_data/vcf_files/
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp  -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantsToTable -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps_final.vcf -F CHROM -F POS -F ID -F QUAL -F AC -F BaseCounts -o /home/ubuntu/batchnumber/raw_data/vcf_files/"$run"filtered_snps_final.table
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantFiltration -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_indels_recal.vcf --filterExpression 'QD < 2.0 || FS > 200.0 || SOR > 10.0' --filterName "basic_indel_filter" -o /home/ubuntu/batchnumber/working_directory/"$run"filtered_indels_recal.vcf
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/filter2.log

