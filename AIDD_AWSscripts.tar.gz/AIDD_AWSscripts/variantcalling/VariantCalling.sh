#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
echo "which step would you like to start on? 1=beginning 2=markduplicates 3=haplotype 4=filter 5=haplotype2 6=filter2 7=snpEff"
read steps
if [ "$steps" == "1" ]; then
echo "Starting with preping bam files for variant calling"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/prepbam.sh
echo "Marking duplicates getting ready for variant calling"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/markduplicates.sh
echo "Running haplotype caller for the first time"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype.sh
echo "Filtering raw variants"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter.sh
echo "Running haplotype two on filtered files"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype2.sh
echo "Running second filtering round to create final vcf files"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter2.sh
echo "Running snpEff to predict variants effect on protein structure and functions"
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run".gene.txt
echo "Reorganizing final vcf files in proper directories"
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
rm /home/ubuntu/batchnumber/working_directory/*.vcf
for i in haplotype filter haplotype2 filter2 snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"NoCounts"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
if [ "$steps" == "2" ]; then
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/markduplicates.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run"_gene.txt
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
for i in haplotype filter haplotype2 filter2 snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
if [ "$steps" == "3" ]; then
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run"_gene.txt
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
for i in haplotype filter haplotype2 filter2 snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
if [ "$steps" == "4" ]; then
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run"_gene.txt
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
for i in filter haplotype2 filter2 snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
if [ "$steps" == "5" ]; then
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/haplotype2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run"_gene.txt
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
for i in haplotype2 filter2 snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
if [ "$steps" == "6" ]; then
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/filter2.sh
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run"_gene.txt
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
for i in filter2 snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
if [ "$steps" == "7" ]; then
bash /home/ubuntu/batchnumber/AIDD/AIDD/variantcalling/snpEff.sh
mv /home/ubuntu/batchnumber/working_directory/"$run".genes.txt /home/ubuntu/batchnumber/raw_data/snpEff/"$run"_gene.txt
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"/
done
for i in snpEff ; do 
sed -i 's/\-A BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/\-F BaseCounts //g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variants/raw_variantsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snps/raw_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indels/raw_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snps/filtered_snpsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indels/filtered_indelsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_data/recal_dataNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_reads/recal_readsNoCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
bash /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_variantsNoCounts/raw_variants/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/AC/ \-A BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/cigar/cigar \-F BaseCounts/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_snpsNoCounts/raw_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/raw_indelsNoCounts/raw_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_snpsNoCounts/filtered_snps/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/filtered_indelsNoCounts/filtered_indels/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_dataNoCounts/recal_data/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
sed -i 's/recal_readsNoCounts/recal_reads/g' /home/ubuntu/batchnumber/AIDD/variantcalling/"$i".sh
done
for i in raw final filtered; do
mv /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/*"$i"* /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"/
done
fi
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/VariantCalling.log

