#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    ##this will set up filtering guidelines in bam files
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp -jar /home/ubuntu/AIDD/AIDD_tools/picard.jar AddOrReplaceReadGroups I=/home/ubuntu/batchnumber/raw_data/bam_files/"$run".bam O=/home/ubuntu/batchnumber/working_directory/"$run"_2.bam RGID=4 RGLB=lib1 RGPL=illumina RGPU=unit1 RGSM=20
    ##this will reorder alignment files 
    java -jar /home/ubuntu/AIDD/AIDD_tools/picard.jar ReorderSam I=/home/ubuntu/batchnumber/working_directory/"$run"_2.bam O=/home/ubuntu/batchnumber/working_directory/"$run"_3.bam R=/home/ubuntu/AIDD/references/ref2.fa CREATE_INDEX=TRUE
    ##this removes unused intermediate files
    rm /home/ubuntu/batchnumber/working_directory/"$run"_2.bam
    ##this collect alignment metrics and piut them in quality control for ubuntu to look at for accuracy
    java -jar /home/ubuntu/AIDD/AIDD_tools/picard.jar CollectAlignmentSummaryMetrics R=/home/ubuntu/AIDD/references/ref2.fa I=/home/ubuntu/batchnumber/working_directory/"$run"_3.bam O=/home/ubuntu/batchnumber/working_directory/"$run"_alignment_metrics.txt
    cp /home/ubuntu/batchnumber/working_directory/"$run"_alignment_metrics.txt /home/ubuntu/batchnumber/quality_control/alignment_metrics/
    ##collect more metrics for quality summary
    java -jar /home/ubuntu/AIDD/AIDD_tools/picard.jar CollectInsertSizeMetrics INPUT=/home/ubuntu/batchnumber/working_directory/"$run"_3.bam OUTPUT=/home/ubuntu/batchnumber/working_directory/"$run"_insert_metrics.txt HISTOGRAM_FILE=/home/ubuntu/batchnumber/working_directory/"$run"_insert_size_histogram.pdf
    cp /home/ubuntu/batchnumber/working_directory/"$run"_insert_metrics.txt /home/ubuntu/batchnumber/quality_control/insert_metrics/
    cp /home/ubuntu/batchnumber/working_directory/"$run"_insert_size_histogram.pdf /home/ubuntu/batchnumber/quality_control/insert_metrics/
    ##creates depth file for quality control on variant calling.
    samtools depth /home/ubuntu/batchnumber/working_directory/"$run"_3.bam > /home/ubuntu/batchnumber/working_directory/"$run"depth_out.txt
    rm /home/ubuntu/batchnumber/working_directory/"$run"_alignment_metrics.txt
    rm /home/ubuntu/batchnumber/working_directory/"$run"_insert_metrics.txt
    rm /home/ubuntu/batchnumber/working_directory/"$run"_insert_size_histogram.pdf
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/prepbam.log
