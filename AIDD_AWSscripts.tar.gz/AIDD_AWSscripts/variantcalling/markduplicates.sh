#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
##this runs mark duplicates
echo "starting mark duplicates this can take a few hours for each sample in the experiment"
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp -jar /home/ubuntu/AIDD/AIDD_tools/picard.jar MarkDuplicates INPUT=/home/ubuntu/batchnumber/working_directory/"$run"_3.bam OUTPUT=/home/ubuntu/batchnumber/working_directory/"$run"_dedup_reads.bam METRICS_FILE=/home/ubuntu/batchnumber/working_directory/"$run"metrics.txt
    rm /home/ubuntu/batchnumber/working_directory/"$run"_3.bam
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/markduplicates.log
