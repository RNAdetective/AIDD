#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATA.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    ##run java tool picard to decompress output sam files from aligner to the bam files needed for both assembly and variant calling.
    java -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp -jar /home/ubuntu/AIDD/AIDD_tools/picard.jar SortSam INPUT=/home/ubuntu/batchnumber/working_directory/"$run".sam OUTPUT=/home/ubuntu/batchnumber/raw_data/bam_files/"$run".bam SORT_ORDER=coordinate
    ##the assembly step using stringtie is run creating tab count files as well as ballgown input files and gtf files which will be used for downstream R analysis.
    stringtie /home/ubuntu/batchnumber/raw_data/bam_files/"$run".bam -p3 -G /home/ubuntu/AIDD/references/ref.gtf -A /home/ubuntu/batchnumber/raw_data/counts/"$run".tab -l -e -o /home/ubuntu/batchnumber/raw_data/ballgown/"$sample"/"$sample".gtf
    
   
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/assembly.log
