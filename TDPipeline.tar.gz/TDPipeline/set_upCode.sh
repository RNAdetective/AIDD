#!/usr/bin/env bash
## this allows user to access shared folders
sudo adduser user vboxsf
##this updates java for the picard tool
sudo apt-add-repository ppa:openjdk-r/ppa
sudo apt-get update
sudo apt-get install openjdk-8-jdk
y
sudo update-alternatives --config java
##this installs curl and other attachments for adding R packages later
sudo apt-get install curl
y
sudo service apache2 restart
sudo apt-get install php5-curl
y
sudo service apache2 restart
sudo apt-get install aptitude
y
sudo apt-get install libcurl4-openssl-dev
y
sudo apt-get install libxml2-dev
y
sudo apt-get install libssl-dev
y
sudo apt-get install libgsl0ldbl
y
sudo apt-get install gsl-bin libgsl0-dev
y
sudo apt-get install gsl-bin libgsl2
y
sudo apt-get install libtiff-dev
y
sudo apt-get install build-essential python2.7-dev python-htseq
y
## this uninstalls old version of R that came with biolinux8
sudo apt-get remove r-base-core
y
## the following adds permission and downloads the newest version of R sets R up for R package downloads required for analysis.
echo "add the following to the file(copy and paste):  deb http://cran.rstudio.com/bin/linux/ubuntu precise/ to the end of the file and then close the pop up window"
sudo gedit /etc/apt/sources.list
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E084DAB9
sudo add-apt-repository ppa:marutter/rdev
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install r-base
y
## this downloads the tool that allows R to find and downloads certain packages needed for analysis.
sudo apt-get install r-cran-rmysql
y

