#!/usr/bin/env bash
echo "Creating Directory system and moving indexes, references and scripts for analysis"
mkdir /home/ubuntu/batchnumber/
##copies PHENO_DATAbatchnumber file into directories for analysis
wget https://github.com/RNAdetective/AIDD/raw/master/batches/PHENO_DATAbatchnumber.csv
mv /home/ubuntu/PHENO_DATAbatchnumber.csv /home/ubuntu/batchnumber/
## creates main directory in sf_AIDD folder
for i in raw_data Results quality_control working_directory AIDD ExToolset indexes tmp ; do
    mkdir /home/ubuntu/batchnumber/$i/
done
##this moves ExToolset
cp /home/ubuntu/AIDD/ExToolset/* /home/ubuntu/batchnumber/ExToolset/
##This will create subdirectories for script transfer of AIDD and tool sets
for i in align_assemble prep Rscripts variantcalling ; do
    mkdir /home/ubuntu/batchnumber/AIDD/$i/
    cp /home/ubuntu/AIDD/AIDD/$i/* /home/ubuntu/batchnumber/AIDD/$i/
done
##This will create subdirectories for prebuilt indexes
for i in gene_list index transcript_list variant_list ; do
    mkdir /home/ubuntu/batchnumber/indexes/$i/
    cp /home/ubuntu/AIDD/indexes/$i/* /home/ubuntu/batchnumber/indexes/$i/
done
## makes subdirectories under indexes directory and moves respective indexes to there correct folders
for i in DESeq2 pathway; do
for j in gene transcript variant ; do
    mkdir /home/ubuntu/batchnumber/indexes/"$j"_list/$i/
    cp /home/ubuntu/AIDD/indexes/"$j"_list/$i/* /home/ubuntu/batchnumber/gene_list/$i/
done
done
## moves experimental gene/transcript list from the desktop to the correct index folder to be used for building own on the fly indexes for GEX and TEX tools
for i in gene transcript ; do
cp /home/ubuntu/Desktop/insert_"$i"_of_interest/* /home/ubuntu/batchnumber/indexes/"$i"_list/DESeq2/
cp /home/ubuntu/Desktop/insert_"$i"_lists_for_pathways/* /home/ubuntu/batchnumber/indexes/"$i"_list/pathway/
done
## raw_data directory
for i in counts ballgown ballgown_in bam_files snpEff vcf_files ; do
    mkdir /home/ubuntu/batchnumber/raw_data/$i/
done
##vcf_file directories
for i in NoCounts final filtered raw ; do
mkdir /home/ubuntu/batchnumber/raw_data/vcf_files/"$i"
done
##Nocount directories
for i in final filtered raw ; do
mkdir /home/ubuntu/batchnumber/raw_data/vcf_files/NoCounts/"$i"
done
## quality_control directory
for i in alignment_metrics fastqc recalibration_plots insert_metrics logs; do
    mkdir /home/ubuntu/batchnumber/quality_control/$i/
done
## Results directory
for i in DESeq2 topGO pathway variant_calling ; do
    mkdir /home/ubuntu/batchnumber/Results/$i/
done
## Results/variant_calling subdirectories
for i in substitutions amino_acid nucleotide impact ; do 
    mkdir /home/ubuntu/batchnumber/Results/variant_calling/$i/
done
##this will add subdirectories for G_VEX
for i in amino_acid nucleotide ; do
    mkdir /home/ubuntu/batchnumber/Results/variant_calling/$i/largegraph/
done
    mkdir /home/ubuntu/batchnumber/Results/variant_calling/substitutions/raw/
## this creates subdirectories for PEX tool
for i in tables volcano heatmaps ; do 
    mkdir /home/ubuntu/batchnumber/Results/pathway/$i/
done
## this creates subdirectories for gene level and transcript level for DESeq2 and topGO and variant calling
for i in gene transcript ; do
    mkdir /home/ubuntu/batchnumber/Results/DESeq2/$i/
    mkdir /home/ubuntu/batchnumber/Results/topGO/$i/
    mkdir /home/ubuntu/batchnumber/Results/variant_calling/$i/
done
## this creates subdirectories in DESeq2/gene and DESeq2/transcript
for i in counts differential_expression calibration PCA ; do
for j in gene transcript ; do
    mkdir /home/ubuntu/batchnumber/Results/DESeq2/$j/$i/
done
done
## this creates subdirectories for GEX nad TEX
for j in gene transcript ; do
for i in excitome "$j"ofinterest venndiagrams; do
    mkdir /home/ubuntu/batchnumber/Results/DESeq2/$j/differential_expression/$i
done
done
## this creates subdirectories in variant_calling
for i in high_impact moderate_impact ; do
for j in gene transcript ; do
    mkdir /home/ubuntu/batchnumber/Results/variant_calling/$j/$i/
done
done
##this will create directories for I-VEX
for i in gene transcript ; do
for j in high moderate ; do
for k in $conditionname1 $conditionname2 final ; do
  mkdir /home/ubuntu/batchnumber/Results/variant_calling/"$i"/"$j"_impact/"$k"/
done 
done
done
##this creates subdirectories for python script to convert to gene_count_matrix for DESeq2
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    mkdir /home/ubuntu/batchnumber/raw_data/ballgown/$sample/
done < $INPUT
IFS=$OLDIFS
rm -rf /home/ubuntu/batchnumber/raw_data/ballgown/sample/
##this creates subdirectories for ballgown analysis
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run codition sample t_name2
do
    mkdir /home/ubuntu/batchnumber/raw_data/ballgown_in/$sample/
done < $INPUT
rm -rf /home/ubuntu/batchnumber/raw_data/ballgown_in/sample/
IFS=$OLDIFS
