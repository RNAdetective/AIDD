#!/usr/bin/env bash
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
echo "Which batch? e.g. batch##"
read batch
## this runs script to create folder system and sets up references and scripts for analysis.
sed -i 's/batchnumber/'$batch'/g' /home/ubuntu/AIDD/AIDD/prep/directories.sh
bash /home/ubuntu/AIDD/AIDD/prep/directories.sh
sed -i 's/'$batch'/batchnumber/g' /home/ubuntu/AIDD/AIDD/prep/directories.sh
##this will convert .sra depending on library layout and if you want to download sra files 
echo "Downing samples."
sed -i 's/batchnumber/'$batch'/g' /home/ubuntu/AIDD/AIDD/prep/downloads_sra.sh
bash /home/ubuntu/AIDD/AIDD/prep/downloads_sra.sh
sed -i 's/'$batch'/batchnumber/g' /home/ubuntu/AIDD/AIDD/prep/downloads_sra.sh
## this will trim sequences
echo "Trimming fastq files."
sed -i 's/batchnumber/'$batch'/g' /home/ubuntu/AIDD/AIDD/prep/trim.sh
bash /home/ubuntu/AIDD/AIDD/prep/trim.sh
sed -i 's/'$batch'/batchnumber/g' /home/ubuntu/AIDD/AIDD/prep/trim.sh
## this will run HISAT2
echo "Starting alignment fastq files"
sed -i 's/batchnumber/'$batch'/g' /home/ubuntu/AIDD/AIDD/align_assemble/HISAT2.sh
bash /home/ubuntu/AIDD/AIDD/align_assemble/HISAT2.sh
sed -i 's/'$batch'/batchnumber/g' /home/ubuntu/AIDD/AIDD/align_assemble/HISAT2.sh
## this will convert sam to bam and then run stringtie
echo "Starting assembly with stringtie"
sed -i 's/batchnumber/'$batch'/g' /home/ubuntu/AIDD/AIDD/align_assemble/assembly.sh
bash /home/ubuntu/AIDD/AIDD/align_assemble/assembly.sh
sed -i 's/'$batch'/batchnumber/g' /home/ubuntu/AIDD/AIDD/align_assemble/assembly.sh
##this is the python script to transform all gtf count files into one matrix file for usage in R analysis.
echo "Starting python script to find gene and transcript counts"
cd /home/ubuntu/batchnumber/raw_data/
python /home/ubuntu/AIDD/AIDD_tools/bin/prepDE.py -g /home/ubuntu/batchnumber/Results/DESeq2/gene/counts/gene_count_matrix.csv -t /home/ubuntu/batchnumber/Results/DESeq2/transcript/counts/transcript_count_matrix.csv
cd "/home/ubuntu/"
##this will run variant calling
echo "Starting variant calling."
for i in VariantCalling prepbam markduplicates haplotype filter haplotype2 filter2 snpEff ; do
sed -i 's/batchnumber/'$batch'/g' /home/ubuntu/AIDD/AIDD/variantcalling/$i.sh
done
bash /home/ubuntu/AIDD/AIDD/variantcalling/VariantCalling.sh
for i in VariantCalling prepbam markduplicates haplotype filter haplotype2 filter2 snpEff ; do
sed -i 's/'$batch'/batchnumber/g' /home/ubuntu/AIDD/AIDD/variantcalling/$i.sh
done
## clean up working directory
echo "Is the experiment done? yes or no."
read expdone
if [ "$expdone" == "yes" ]; then
## clean up working directory
rm /home/ubuntu/$batch/working_directory/*
## compress files to get ready to move.
tar cvzf $batch.tar.gz /home/ubuntu/$batch/
fi

