#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    ##creates fitered variants
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T SelectVariants -R /home/ubuntu/AIDD/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_variants.vcf -selectType SNP -o /home/ubuntu/batchnumber/working_directory/"$run"raw_snps.vcf
    ##moves files
    mv /home/ubuntu/batchnumber/working_directory/"$run"raw_snps.vcf /home/ubuntu/batchnumber/raw_data/vcf_files/
    ##runs variants to table for easier viewing of vcf files
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp  -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantsToTable -R /home/ubuntu/AIDD/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_snps.vcf -F CHROM -F POS -F ID -F QUAL -F AC -F BaseCounts -o /home/ubuntu/batchnumber/raw_data/vcf_files/"$run"raw_snps.table
    ##select more variants for filtering
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T SelectVariants -R /home/ubuntu/AIDD/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_variants.vcf -selectType INDEL -o /home/ubuntu/batchnumber/working_directory/"$run"raw_indels.vcf
    ##starting filtering steps
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantFiltration -R /home/ubuntu/AIDD/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_snps.vcf --filterExpression 'QD < 2.0 || FS > 60.0 || MQ < 40.0 || SOR > 4.0' --filterName "basic_snp_filter" -o /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps.vcf
    ##moves and converts vcf filtered snp file into table
    mv /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps.vcf /home/ubuntu/batchnumber/raw_data/vcf_files/
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp  -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantsToTable -R /home/ubuntu/AIDD/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps.vcf -F CHROM -F POS -F ID -F QUAL -F AC -F BaseCounts -o /home/ubuntu/batchnumber/raw_data/vcf_files/"$run"filtered_snps.table
    ##more filtering
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantFiltration -R /home/ubuntu/AIDD/references/ref2.fa -V /home/ubuntu/batchnumber/working_directory/"$run"raw_indels.vcf --filterExpression 'QD < 2.0 || FS > 200.0 || SOR > 10.0' --filterName "basic_indel_filter" -o /home/ubuntu/batchnumber/working_directory/"$run"filtered_indels.vcf
    ##rns base recalibrator to create new bam files with filtering taken into account
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T BaseRecalibrator -R /home/ubuntu/AIDD/references/ref2.fa -I /home/ubuntu/batchnumber/working_directory/"$run"_dedup_reads.bam -knownSites /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps.vcf -knownSites /home/ubuntu/batchnumber/working_directory/"$run"filtered_indels.vcf --filter_reads_with_N_cigar -o /home/ubuntu/batchnumber/working_directory/"$run"recal_data.table
    ##moves and converts vcf files
    mv /home/ubuntu/batchnumber/working_directory/"$run"recal_data.table /home/ubuntu/batchnumber/quality_control/recalibration_plots/
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T BaseRecalibrator -R /home/ubuntu/AIDD/references/ref2.fa -I /home/ubuntu/batchnumber/working_directory/"$run"_dedup_reads.bam -knownSites /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps.vcf -knownSites /home/ubuntu/batchnumber/working_directory/"$run"filtered_indels.vcf -BQSR /home/ubuntu/batchnumber/working_directory/"$run"recal_data.table --filter_reads_with_N_cigar -o /home/ubuntu/batchnumber/working_directory/"$run"post_recal_data.table
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T AnalyzeCovariates -R /home/ubuntu/AIDD/references/ref2.fa -before /home/ubuntu/batchnumber/working_directory/"$run"recal_data.table -after /home/ubuntu/batchnumber/working_directory/"$run"post_recal_data.table -plots /home/ubuntu/batchnumber/working_directory/"$run"recalibration_plots.pdf
    ##creates new bam file containing filtering data.
    java -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T PrintReads -R /home/ubuntu/AIDD/references/ref2.fa -I /home/ubuntu/batchnumber/working_directory/"$run"_dedup_reads.bam -BQSR /home/ubuntu/batchnumber/working_directory/"$run"recal_data.table --filter_reads_with_N_cigar -o /home/ubuntu/batchnumber/working_directory/"$run"recal_reads.bam
    rm /home/ubuntu/batchnumber/working_directory/"$run"_dedup_reads.bam
    ##moves recalibration plots to quality control directories for later ubuntu evaluation
    mv /home/ubuntu/batchnumber/working_directory/"$run"post_recal_data.table /home/ubuntu/batchnumber/quality_control/recalibration_plots/
    mv /home/ubuntu/batchnumber/working_directory/"$run"recalibration_plots.pdf /home/ubuntu/batchnumber/quality_control/recalibration_plots/
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/filter.log
