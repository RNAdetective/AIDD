#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    ##runs snpEff with provided references to annotate vcf files with effect of variant on protein structure and function.
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp -jar /home/ubuntu/AIDD/AIDD_tools/snpEff.jar -v GRCh37.75 /home/ubuntu/batchnumber/working_directory/"$run"filtered_snps_final.vcf -stats /home/ubuntu/batchnumber/raw_data/snpEff/"$run" -csvStats /home/ubuntu/batchnumber/raw_data/snpEff"$run".csv > /home/ubuntu/batchnumber/raw_data/snpEff/"$run"filtered_snps_final.ann.vcf
    ##converts final annotationed vcf to table for easier processing
    java -d64 -Xmx20G -XX:-UseGCOverheadLimit -XX:ParallelGCThreads=2 -XX:ReservedCodeCacheSize=1024M -Djava.io.tmpdir=/home/ubuntu/batchnumber/tmp  -jar /home/ubuntu/AIDD/AIDD_tools/GenomeAnalysisTK.jar -T VariantsToTable -R /home/ubuntu/batchnumber/references/ref2.fa -V /home/ubuntu/batchnumber/raw_data/snpEff/"$run"filtered_snps_final.ann.vcf -F CHROM -F POS -F ID -F QUAL -F AC -F BaseCounts -o /home/ubuntu/batchnumber/raw_data/vcf_files/"$run"filtered_snps_final.ann.table
    mv /home/ubuntu/batchnumber/raw_data/*.csv /home/ubuntu/batchnumber/raw_data/snpEff/
    mv /home/ubuntu/batchnumber/raw_data/*.txt /home/ubuntu/batchnumber/raw_data/snpEff/
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/snpEff.log
