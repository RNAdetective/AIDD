#!/usr/bin/env bash
main_function() {
export PATH=$PATH:/home/ubuntu/AIDD/AIDD_tools/bin
INPUT=/home/ubuntu/batchnumber/PHENO_DATAbatchnumber.csv
OLDIFS=$IFS
IFS=,
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read  x run condition sample t_name2
do
    ##this runs alignment tool HISAT2 with paired end reads.  It creates a sam file containing alignment as well as count files that can be compared to strintie counts for ensured accuracy
    hisat2 -q -x /home/ubuntu/AIDD/references/genome -p3 --dta-cufflinks -1 /home/ubuntu/batchnumber/working_directory/"$run"_1.fastq -2 /home/ubuntu/batchnumber/working_directory/"$run"_2.fastq -t --summary-file /home/ubuntu/batchnumber/quality_control/alignment_metrics/"$run".txt -S /home/ubuntu/batchnumber/working_directory/"$run".sam
    ##this will remove the fastq files when done
    rm /home/ubuntu/batchnumber/working_directory/"$run"_1.fastq
    rm /home/ubuntu/batchnumber/working_directory/"$run"_2.fastq
done < $INPUT
IFS=$OLDIFS
}
main_function 2>&1 | tee -a /home/ubuntu/batchnumber/quality_control/logs/HISAT2.log
